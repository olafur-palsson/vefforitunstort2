# Vefforritun, stórt verkefni 2

*Kóðað af:*

Ólafur Pálsson - olp6@hi.is

Ólafur Sverrir Gunnarsson - osg@hi.is

Þorgeir Sigurðarson - ths222@hi.is

# Install instructions

1. Downloada zip
2. Extracta það
3. Keyra npm install
4. Keyra npm run dev

Frekar straight forward